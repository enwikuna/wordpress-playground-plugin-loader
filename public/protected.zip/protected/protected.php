<?php
/**
 * Plugin Name: Protected
 * Description: A test plugin
 * Version: 1.0
 * Author: bgrgicak
 * Author URI: https://bero.dev
 */

function init() {
    error_log('Protected is running')
}
add_action('init', 'init');
