<?php
/**
 * Plugin Name: Free
 * Description: A test plugin
 * Version: 1.0
 * Author: bgrgicak
 * Author URI: https://bero.dev
 */

function init() {
    error_log('Free is running')
}
add_action('init', 'init');
